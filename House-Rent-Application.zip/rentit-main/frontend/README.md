# Frontend 
MUI, Tailwind CSS & LUCID-REACT (for icons)

