# APP Backend 
express.js app 
socket.io for realtime chat and request updates.
multer + cloudinary for file uploads

src/lib/geocode cached address to geocode (uses two free apis)

payment- dummy
property & user verifcation - dummy
